<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Enrkipsi dan Dekripsi Rivest Shamir Adleman</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

  <!-- Plugin CSS -->
  <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template -->
  <link href="css/freelancer.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg bg-secondary fixed-top text-uppercase" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top">Rivest Shamir Adleman</a>
      <button class="navbar-toggler navbar-toggler-right text-uppercase bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fa fa-bars"></i>
      </button>
      <!-- <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="enkripsi.php">Enkripsi</a>
          </li>
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="dekripsi.php">Dekripsi</a>
          </li>
        </ul>
      </div> -->
    </div>
  </nav>

  <!-- Header -->
  <header class="masthead bg-primary text-white text-center">
    <div class="container">
      <img class="img-fluid mb-5 d-block mx-auto" src="img/lock.png" alt="">
      <h1 class="text-uppercase mb-0">Enrkipsi dan Dekripsi</h1>
      <hr class="star-light">
      <hr>  
      <h4 class="font-weight-light mb-0">Masukan Password</h4>
      <br> 
     <form method="post" action="masterdata.php">
    <div class="input-group mb-3">
      <input type="password" name="password" class="form-control" placeholder="Enter Password" aria-label="Enter Password" aria-describedby="button-addon2">
      <div class="input-group-append">
        <button class="btn btn-outline-secondary" type="submit" id="button-addon2" style="background: #2c3e50; border: #2c3e50; color: #fff;">Submit</button>
      </div>
    </div>

    <!-- <input type="password" class="form-control" id="password" name="password"> -->
    <!-- <input type="submit" name="submit" value="submit"> -->
  </form>
</div>
</header>
<!--       <hr class="colorgraph">
      <div class="row">
        <div class="col-xs-12 col-md-6"><button class="btn btn-success" name="masuk">Masuk</button></div>
      </div>
    </header> -->

    <!-- About Section -->
    <section class="bg-primary text-white mb-0" id="about">
      <div class="container">
        <h2 class="text-center text-uppercase text-white">Apa Itu Enkripsi dan Dekripsi?</h2>
        <hr class="star-light mb-5">
        <div class="row">
          <div class="col-lg-4 ml-auto">
            <p class="lead">Enkripsi adalah sebuah proses yang melakukan perubahan bentuk data dari yang bisa dimengerti menjadi sebuah kode yang tidak dapat dimengerti oleh manusia.</p>
          </div>
          <div class="col-lg-4 mr-auto">
            <p class="lead">Begitu pula dengan dekripsi merupakan sebuah proses pengembalian data dari sebuah kode yang tidak dapat dimengerti atau chiper menjadi sebuah karakter atau kebentuk asalnya yang biasa disebut dengan plain text.</p>
          </div>
        </div>
        <!-- <div class="text-center mt-4">
          <a class="btn btn-xl btn-outline-light" href="#">
            <i class="fa fa-download mr-2"></i>
            Download Now!
          </a>
        </div> -->
      </div>
    </section>

    <!-- Footer -->
    <footer class="footer text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-4 mb-5 mb-lg-0">
            <h4 class="text-uppercase mb-4">Location</h4>
            <p class="lead mb-0">Muhammad Pandu Affandi
              <br>Griya Nusa Permai No.4 
              <br>Ngawen RT.02 RW.11,
              <br>Ngawen Prihanggo,
              <br>Gamping, Sleman Yogyakarta
              <br>55291
            </p>
            </div>
            <div class="col-md-4 mb-5 mb-lg-0">
              <h4 class="text-uppercase mb-4">Social Media</h4>
              <ul class="list-inline mb-0">
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="http://facebook.com/panduaffandi">
                    <i class="fa fa-fw fa-facebook"></i>
                  </a>
                </li>
                <!-- <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="http://gmail.com/enkripsidekripsi">
                    <i class="fa fa-fw fa-envelope"></i>
                  </a>
                </li> -->
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="http://twitter.com/enkripsiRSA">
                    <i class="fa fa-fw fa-twitter"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="https://www.linkedin.com/in/hansha-43a525176">
                    <i class="fa fa-fw fa-linkedin"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="http://instagram.com/pandwafn">
                    <i class="fa fa-fw fa-instagram"></i>
                  </a>
                </li>
              </ul>
            </div>
            <div class="col-md-4">
              <h4 class="text-uppercase mb-4"></h4>
              <p class="lead mb-0">Untuk mendapatkan password agar dapat mengakses website ini silahkan kunjungi media sosial yang terdapat disamping tulisan ini, atau kirim pesan via Whatsapp.
                <a href="http://wa.me/082243533194">Klik disini!</a></p>
              </div>
            </div>
          </div>
        </footer>

        <div class="copyright py-4 text-center text-white">
          <div class="container">
            <small>Copyright &copy; Muhammad Pandu Affandi 2020</small>
          </div>
        </div>

        <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
        <div class="scroll-to-top d-lg-none position-fixed ">
          <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
            <i class="fa fa-chevron-up"></i>
          </a>
        </div>

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Plugin JavaScript -->
        <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
        <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

        <!-- Contact Form JavaScript -->
        <script src="js/jqBootstrapValidation.js"></script>
        <script src="js/contact_me.js"></script>

        <!-- Custom scripts for this template -->
        <script src="js/freelancer.min.js"></script>

      </body>

      </html>
