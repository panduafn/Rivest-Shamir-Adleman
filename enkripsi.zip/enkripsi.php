<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Enrkipsi Rivest Shamir Adleman</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

  <!-- Plugin CSS -->
  <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template -->
  <link href="css/freelancer.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg bg-secondary fixed-top text-uppercase" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">Rivest Shamir Adleman</a>
      <button class="navbar-toggler navbar-toggler-right text-uppercase bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fa fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="enkripsi.php">Enkripsi</a>
          </li>
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="dekripsi.php">Dekripsi</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Header -->
  <header class="masthead bg-primary text-white text-center">
    <div class="container">
      <img class="img-fluid mb-5 d-block mx-auto" src="img/lock.png" alt="">
      <h1 class="text-uppercase mb-0">Enrkipsi</h1>
      <hr>
       <h5 class="font-weight-light mb-0">Enkripsi adalah sebuah proses yang melakukan perubahan bentuk data dari yang bisa dimengerti menjadi sebuah kode yang tidak bisa dimengerti. Hasil dari enkripsi khususnya dengan menggunakan metode Rivest Shamir Adleman adalah sebuah angka.</h5>
      <hr class="star-light">
  </div>
</header>
      <!-- <h2 class="font-weight-light mb-0">Proses Enkripsi</h2> -->
 

<?php 
if (isset($_FILES['file1'])) {
    move_uploaded_file($_FILES["file1"]["tmp_name"], 'enkripsi.txt');
    $myfile = fopen("enkripsi.txt", "r") or die("Unable to open file!");
    $isiteks = fread($myfile,filesize("enkripsi.txt"));
    fclose($myfile);
}

?>
<html>  
<body>
   

<div class="container">    
                <div class="panel panel-default">
                    <div class="panel panel-body">
                         <title>Enkripsi Rivest Shamir Adleman</title>    
                         <hr>
    <h2 class="font-weight-light mb-0">Hasil Enkripsi</h2>
    <br>
    <textarea id="hasil" class="form-control" readonly=""> 
     <?php 
     $hasil=null;
     if(!empty($_POST['enkrip'])){
        $n=$_POST['n'];
        $e=$_POST['e'];
        $teks=$_POST['teks']; 
        $txt=null;
    //pesan dikodekan menjadi kode ascii, kemudian di enkripsi per karakter
        for($i=0;$i<strlen($teks);++$i){

        //rumus enkripsi <enkripsi>=<pesan>^<e>mod<n>
            $hasil = gmp_strval(gmp_mod(gmp_pow(ord($teks[$i]),$e),$n));

        //antar tiap karakter dipisahkan dengan "."
            if($i!=strlen($teks)-1){
                echo $hasil.=".";
                $txt=$txt.$hasil;
            }
        }
    }

    if($hasil){
        echo $hasil;
        $txt=$txt.$hasil;
    }
    ?>
</textarea>
<br>
<br>
<br>

<?php 
if(isset($hasil)){
    $myfile = fopen("enkripsi.txt", "w") or die("Unable to open file!");
    fwrite($myfile, $txt);
    fclose($myfile);
    ?>

    

    <?php
}
?>
                   <!--  <h3>ENKRIPSI RIVEST SHAMIR ADLEMAN</h3> -->
                    <form method="post" enctype="multipart/form-data">  
                       <!--  <title>Enkripsi Rivest Shamir Adleman</title> -->
                        <div class="form">
                            <h4 class="font-weight-light mb-0">Silahkan Upload File Untuk Enkripsi</h4>
                            <input type="file" class="form-control" name="file1">
                            <br>
                            <button class="btn btn-primary" type="submit" ><i class="fa fa-upload"></i> Upload</button>
                            <a class="btn btn-primary" href="enkripsi.txt" download><i class="fa fa-download"></i> Download Hasil</a>
                        </div>
                    </form>
<hr>
                    <form id="enkripsi" name="enkripsi" method="post">
   <textarea name="teks" id="teks" class="form-control" placeholder="PLAIN TEKS" readonly="" ><?php if (isset($isiteks)): ?><?=$isiteks?><?php endif ?></textarea>
   <div class="form-group">
       <label for="">Modulus (Pembagi)</label>
        <input type="text" name="n" id="n" class="form-control" size="30" value="" required />

</div>      
     <div class="form-group">
     <label for="">Kunci Publik</label>
   <input type="text" name="e" id="e" class="form-control" size="10" value="" required />
      </div>
   <!-- <input type="submit" name="enkrip" id="enkrip" value="ENKRIPSI"/> -->
   <br>
   <button type="submit" class="btn btn-primary" name="enkrip" id="enkrip" value="ENKRIPSI">Proses</button>
</form>
<hr>
                </div>
            </div>
    </div>

    <style type="text/css">
        input,label{
            display:block;
        }
        textarea{
            font-family: Helvetica, Arial;
            line-height: 1.1em;
            font-size:20pt;
            text-align:left;            
            width:800px;
            height:400px;
        }
        #hasil{
            padding:20px;
            background:white;
            color:black;
            font-family:arial;
        }

    </style>


<!-- <form method="post" action="email.php">
        <input type="text" name="email" placeholder="email"/>
        <br> 
        <input type="hidden" name="jenis" value="enkripsi">
        <input type="submit" name="kirim" id="kirim" value="kirim"/>
    </form> -->
    <footer class="footer text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-4 mb-5 mb-lg-0">
            <h4 class="text-uppercase mb-4">Location</h4>
            <p class="lead mb-0">Muhammad Pandu Affandi
              <br>Griya Nusa Permai No.4 
              <br>Ngawen RT.02 RW.11,
              <br>Ngawen Prihanggo,
              <br>Gamping, Sleman Yogyakarta
              <br>55291
          </p>
            </div>
            <div class="col-md-4 mb-5 mb-lg-0">
              <h4 class="text-uppercase mb-4">Social Media</h4>
              <ul class="list-inline mb-0">
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="http://facebook.com/panduaffandi">
                    <i class="fa fa-fw fa-facebook"></i>
                  </a>
                </li>
                <!-- <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                    <i class="fa fa-fw fa-google-plus"></i>
                  </a>
                </li> -->
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="http://twitter.com/enkripsiRSA">
                    <i class="fa fa-fw fa-twitter"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="https://www.linkedin.com/in/hansha-43a525176">
                    <i class="fa fa-fw fa-linkedin"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="http://instagram.com/pandwafn">
                    <i class="fa fa-fw fa-instagram"></i>
                  </a>
                </li>
              </ul>
            </div>
            <div class="col-md-4">
              <h4 class="text-uppercase mb-4"></h4>
              <p class="lead mb-0">Untuk mendapatkan password agar dapat mengakses website ini silahkan kunjungi media sosial yang terdapat disamping tulisan ini, atau kirim pesan via Whatsapp.
                <a href="http://wa.me/082243533194">Klik disini!</a></p>
              </div>
            </div>
          </div>
        </footer>

        <div class="copyright py-4 text-center text-white">
          <div class="container">
            <small>Copyright &copy; Muhammad Pandu Affandi 2020</small>
          </div>
        </div>

        <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
        <div class="scroll-to-top d-lg-none position-fixed ">
          <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
            <i class="fa fa-chevron-up"></i>
          </a>
        </div>

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Plugin JavaScript -->
        <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
        <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

        <!-- Contact Form JavaScript -->
        <script src="js/jqBootstrapValidation.js"></script>
        <script src="js/contact_me.js"></script>

        <!-- Custom scripts for this template -->
        <script src="js/freelancer.min.js"></script>
</body>
</html>