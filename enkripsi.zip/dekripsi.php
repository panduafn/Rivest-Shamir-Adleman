<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Dekripsi Rivest Shamir Adleman</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

  <!-- Plugin CSS -->
  <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template -->
  <link href="css/freelancer.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg bg-secondary fixed-top text-uppercase" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">Rivest Shamir Adleman</a>
      <button class="navbar-toggler navbar-toggler-right text-uppercase bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fa fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="enkripsi.php">Enkripsi</a>
          </li>
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="dekripsi.php">Dekripsi</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Header -->
  <header class="masthead bg-primary text-white text-center">
    <div class="container">
      <img class="img-fluid mb-5 d-block mx-auto" src="img/lock.png" alt="">
      <h1 class="text-uppercase mb-0">Dekripsi</h1>
      <hr>
       <h5 class="font-weight-light mb-0">Dekripsi merupakan sebuah proses pengembalian data dari sebuah kode atau hasil dari enkripsi yang tidak dapat dimengerti menjadi sebuah karakter atau kebentuk semula yang biasa disebut dengan plain text.</h5>
      <hr class="star-light">
      <!-- <h2 class="font-weight-light mb-0">Proses Enkripsi</h2> -->
     </div>
 </header>
    <!-- <input type="password" class="form-control" id="password" name="password"> -->
    <!-- <input type="submit" name="submit" value="submit"> -->
<div class="container">
    

<?php 
if (isset($_FILES['file1'])) {
    move_uploaded_file($_FILES["file1"]["tmp_name"], 'dekripsi.txt');
    $myfile = fopen("dekripsi.txt", "r") or die("Unable to open file!");
    $isiteks = fread($myfile,filesize("dekripsi.txt"));
    fclose($myfile);
}
?>

<?php
if(!empty($_POST['dekrip'])){
    $n=$_POST['n'];
    $d=$_POST['d'];
    $hasil=null;
    $txt=null;
    
    //pesan enkripsi dipecah menjadi array dengan batasan "."
    $teks=explode(".",$_POST['teks']);
    foreach($teks as $nilai){

        //rumus enkripsi <pesan>=<enkripsi>^<d>mod<n>
        $hasil.=chr(gmp_strval(gmp_mod(gmp_pow($nilai,$d),$n)));
        // $txt=$txt.$hasil;
    }
    if($hasil){
        // echo $hasil; //ini yg bikin tampil tadi
        $txt=$txt.$hasil;
    }
    ?>

    <?php
}
?>
<br>
<br>
<?php 
if(isset($hasil)){
    $myfile = fopen("dekripsi.txt", "w") or die("Unable to open file!");
    fwrite($myfile, $txt);
    fclose($myfile);
}
?>
    <style type="text/css">
        input,label{
            display:block;
        }
        textarea{
            font-family: Helvetica, Arial;
            line-height: 1.1em;
            font-size:20pt;
            text-align:left;            
            width:800px;
            height:400px;
        }
        #hasil{
            padding:20px;
            background:white;
            color:black;
            font-family:arial;
        }
    </style>
</head>  
<body>
<h2 class="font-weight-light mb-0">Hasil Dekripsi</h2>
<br>
<textarea id="hasil" class="form-control" readonly="">
    <?php
    if(@$hasil!=null){

        echo "$hasil";
    }
    ?>
</textarea>
    <br>
    <br>
     <div class="container">
            <div class="panel panel-default">
                <div class="panel panel-body">  
                    <form method="post" enctype="multipart/form-data">  
                        <title>Dekripsi Rivest Shamir Adleman</title>
                        <div class="form">
                            <h5 class="font-weight-light mb-0">Silahkan Upload File Hasil Enkripsi</h5>
                            <input type="file" class="form-control" name="file1">
                            <br>
                            <button class="btn btn-primary" name="submit"><i class="fa fa-upload"></i> Upload</button>
                            <a class="btn btn-primary" href="dekripsi.txt" download><i class="fa fa-download"></i> Download Hasil</a>
                        </div>
                    </form>
                    <hr>
                </div>
            </div>
    </div> 
    <form id="enkripsi" name="enkripsi" method="post">
        <textarea name="teks" id="teks" class="form-control" placeholder="CIPHER TEKS" readonly=""><?php if (isset($isiteks)): ?><?=$isiteks?><?php endif ?></textarea>
        <label for="n">Modulus (Pembagi)</label><input type="text" name="n" id="n" class="form-control" size="30" value="" required />
        <label for="d">Kunci Private</label><input type="text" name="d" id="d" class="form-control" size="10" value="" required />
        <!-- <input type="submit" name="dekrip" id="dekrip" value="DEKRIPSI"/> -->
        <br>
        <button type="submit" class="btn btn-primary" name="dekrip" id="dekrip" value="DEKRIPSI">Proses</button>
    </form>
    <hr>
</div>
                                <!-- <form method="post" action="email.php">
                                <input type="text" name="email" placeholder="email"/>
                                <br> 
                                <input type="hidden" name="jenis" value="dekripsi">
                                <input type="submit" name="kirim" id="kirim" value="kirim"/>
                            </form> -->

 <footer class="footer text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-4 mb-5 mb-lg-0">
            <h4 class="text-uppercase mb-4">Location</h4>
            <p class="lead mb-0">Muhammad Pandu Affandi
              <br>Griya Nusa Permai No.4 
              <br>Ngawen RT.02 RW.11,
              <br>Ngawen Prihanggo,
              <br>Gamping, Sleman Yogyakarta
              <br>55291
          </p>
            </div>
            <div class="col-md-4 mb-5 mb-lg-0">
              <h4 class="text-uppercase mb-4">Social Media</h4>
              <ul class="list-inline mb-0">
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="http://facebook.com/panduaffandi">
                    <i class="fa fa-fw fa-facebook"></i>
                  </a>
                </li>
<!--                 <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                    <i class="fa fa-fw fa-google-plus"></i>
                  </a>
                </li> -->
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="https://twitter.com/enkripsiRSA">
                    <i class="fa fa-fw fa-twitter"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="https://www.linkedin.com/in/hansha-43a525176">
                    <i class="fa fa-fw fa-linkedin"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="http://instagram.com/pandwafn">
                    <i class="fa fa-fw fa-instagram"></i>
                  </a>
                </li>
              </ul>
            </div>
            <div class="col-md-4">
              <h4 class="text-uppercase mb-4"></h4>
              <p class="lead mb-0">Untuk mendapatkan password agar dapat mengakses website ini silahkan kunjungi media sosial yang terdapat disamping tulisan ini, atau kirim pesan via Whatsapp.
                <a href="http://wa.me/082243533194">Klik disini!</a></p>
              </div>
            </div>
          </div>
        </footer>

        <div class="copyright py-4 text-center text-white">
          <div class="container">
            <small>Copyright &copy; Muhammad Pandu Affandi 2020</small>
          </div>
        </div>

        <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
        <div class="scroll-to-top d-lg-none position-fixed ">
          <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
            <i class="fa fa-chevron-up"></i>
          </a>
        </div>


        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Plugin JavaScript -->
        <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
        <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

        <!-- Contact Form JavaScript -->
        <script src="js/jqBootstrapValidation.js"></script>
        <script src="js/contact_me.js"></script>

        <!-- Custom scripts for this template -->
        <script src="js/freelancer.min.js"></script>

</body>
</html>