<?php
@$pass = $_POST['password'];

if (empty($pass)) 
{
   echo "<script>alert('Password Tidak Boleh Kosong!');</script>";
   echo "<script>location='index.php';</script>";
}

 if ($pass !== "enkripsidekripsi")
{
   echo "<script>alert('Password yang Anda Masukan Salah!');</script>";
   echo "<script>location='index.php';</script>";
 }
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Master Data Enrkipsi dan Dekripsi</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

  <!-- Plugin CSS -->
  <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template -->
  <link href="css/freelancer.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg bg-secondary fixed-top text-uppercase" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">Rivest Shamir Adleman</a>
      <button class="navbar-toggler navbar-toggler-right text-uppercase bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fa fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="enkripsi.php">Enkripsi</a>
          </li>
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="dekripsi.php">Dekripsi</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Header -->
  <header class="masthead bg-primary text-white text-center">
    <div class="container">
      <img class="img-fluid mb-5 d-block mx-auto" src="img/lock.png" alt="">
      <h1 class="text-uppercase mb-0">Master Data</h1>
      <hr>
      <h4 class="font-weight-light mb-0">Master Data digunakan untuk melakukan proses enkripsi dan dekripsi</h4>
      <hr class="star-light">
    </div>
  </header>
        
<div class="container">
  <hr>
    <pre>
<?php
// echo "<h2>Master Data Enkripsi dan Dekripsi RSA</h2>\n";
echo "<h5>Refresh Halaman Untuk Mengganti Master Data</h2>";
//untuk membuat kunci yang lebih panjang coba gmp_random

//$rand1 = gmp_random(1); // mengeluarkan random number dari 0 sampai 1 x limb

//$rand2 = gmp_random(1); // mengeluarkan random number dari 0 sampai 1 x limb

//mencari bilangan random
$rand1=rand(100,200);
$rand2=rand(100,200);

// mencari bilangan prima selanjutnya dari $rand1 &rand2
$p = gmp_nextprime($rand1); 
$q = gmp_nextprime($rand2);

//menampilkan p & q
ob_start();
echo 'P (RAHASIA) = '.gmp_strval($p) . "\n"; 
echo 'Q (RAHASIA) = '.gmp_strval($q). "\n";

//menghitung&menampilkan n=p*q
$n=gmp_mul($p,$q);
echo 'Modulus = '.gmp_strval($n). "\n";

//menghitung&menampilkan totient/phi=(p-1)(q-1)
$totient=gmp_mul(gmp_sub($p,1),gmp_sub($q,1));
// echo 'totient='.gmp_strval($totient). "\n";

//mencari KP, dimana KP merupakan coprime dari totient
//KP dikatakan coprime dari totient jika gcd/fpb dari KP dan totient/phi = 1
for($e=2;$e<1000;$e++){  //mencoba perulangan max 100 kali, 
    $gcd = gmp_gcd($e, $totient);
    if(gmp_strval($gcd)=='1')
        break;
}

//menampilkan gcd
echo 'gcd = '.gmp_strval($gcd) . "\n";

//menampilkan e
echo 'Kunci Publik = '.gmp_strval($e). "\n";

//cari d
//d.e mod totient =1
// d.e = totient*x + 1
// d.e = totient*1 + 1
// d = (totient *1 + 1)/e

//menghitung & menampilkan d
$i=1;
do{
    $res = gmp_div_qr(gmp_add(gmp_mul($totient,$i),1), $e);
    // echo '((totient*'.$i.') + 1) / e='.gmp_strval($res[0])." ; sisa= ".gmp_strval($res[1])."\n";
    $i++;
    if($i==10000) //maksimal percobaan 10000
        break;
}while(gmp_strval($res[1])!='0');
$d=$res[0];
echo 'Kunci Private = '.gmp_strval($d). "\n";
echo "Hasil test d.e mod totient = ".gmp_strval(gmp_mod(gmp_mul($d,$e),$totient));
echo "\n";
$content=ob_get_contents();
ob_end_flush();
echo "<hr/>\n";
echo "<h2>Hasil</h2>\n";
ob_start();
echo "Desimal :\n";
echo "Modulus = ".gmp_strval($n)."\n";
echo "Kunci Publik = ".gmp_strval($e)."\n";
echo "Kunci private = ".gmp_strval($d)."\n";
$content = $content . ob_get_contents();

// echo "<br>Hexadesimal :\n";
// echo "Modulus = ".gmp_strval($n,16)."\n";
// echo "Kunci Publik = ".gmp_strval($e,16)."\n";
// echo "Kunci Private = ".gmp_strval($d,16)."\n";

// echo "<br>Biner :\n";
// echo "Modulus = ".gmp_strval($n,2)."\n";
// echo "Kunci Publik = ".gmp_strval($e,2)."\n";
// echo "Kunci Private = ".gmp_strval($d,2)."\n";

// echo "<br>Basis 36 :\n";
// echo "Modulus = ".gmp_strval($n,36)."\n";
// echo "Kunci Publik = ".gmp_strval($e,36)."\n";
// echo "Kunci Private = ".gmp_strval($d,36)."\n";
?> 

<?php 
$myfile = fopen("masterdata.txt", "w") or die("Unable to open file!");
    fwrite($myfile, $content);
    fclose($myfile);
 ?>
 <button class="btn btn-primary" type="submit"><a class="btn btn-primary" href="masterdata.txt" download><i class="fa fa-download"></i> Download</a></button>
</pre>
</div>

   <footer class="footer text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-4 mb-5 mb-lg-0">
            <h4 class="text-uppercase mb-4">Location</h4>
            <p class="lead mb-0">Muhammad Pandu Affandi
              <br>Griya Nusa Permai No.4 
              <br>Ngawen RT.02 RW.11,
              <br>Ngawen Prihanggo,
              <br>Gamping, Sleman Yogyakarta
              <br>55291
            </div>
            <div class="col-md-4 mb-5 mb-lg-0">
              <h4 class="text-uppercase mb-4">Social Media</h4>
              <ul class="list-inline mb-0">
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="http://facebook.com/panduaffandi">
                    <i class="fa fa-fw fa-facebook"></i>
                  </a>
                </li>
                <!-- <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                    <i class="fa fa-fw fa-google-plus"></i>
                  </a>
                </li> -->
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="http://twitter.com/enkripsiRSA">
                    <i class="fa fa-fw fa-twitter"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="https://www.linkedin.com/in/hansha-43a525176">
                    <i class="fa fa-fw fa-linkedin"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn btn-outline-light btn-social text-center rounded-circle" href="http://instagram.com/pandwafn">
                    <i class="fa fa-fw fa-instagram"></i>
                  </a>
                </li>
              </ul>
            </div>
            <div class="col-md-4">
              <h4 class="text-uppercase mb-4"></h4>
              <p class="lead mb-0">Untuk mendapatkan password agar dapat mengakses website ini silahkan kunjungi media sosial yang terdapat disamping tulisan ini, atau kirim pesan via Whatsapp.
                <a href="http://wa.me/082243533194">Klik disini!</a></p>
              </div>
            </div>
          </div>
        </footer>

        <div class="copyright py-4 text-center text-white">
          <div class="container">
            <small>Copyright &copy; Muhammad Pandu Affandi 2020</small>
          </div>
        </div>

        <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
        <div class="scroll-to-top d-lg-none position-fixed ">
          <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
            <i class="fa fa-chevron-up"></i>
          </a>
        </div>

        <!-- Portfolio Modals -->

        <!-- Portfolio Modal 1 -->
       <!--  <div class="portfolio-modal mfp-hide" id="portfolio-modal-1">
          <div class="portfolio-modal-dialog bg-white">
            <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
              <i class="fa fa-3x fa-times"></i>
            </a>
            <div class="container text-center">
              <div class="row">
                <div class="col-lg-8 mx-auto">
                  <h2 class="text-secondary text-uppercase mb-0">Project Name</h2>
                  <hr class="star-dark mb-5">
                  <img class="img-fluid mb-5" src="img/portfolio/cabin.png" alt="">
                  <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
                  <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                    <i class="fa fa-close"></i>
                  Close Project</a>
                </div>
              </div>
            </div>
          </div>
        </div> -->

        <!-- Portfolio Modal 2 -->
        <!-- <div class="portfolio-modal mfp-hide" id="portfolio-modal-2">
          <div class="portfolio-modal-dialog bg-white">
            <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
              <i class="fa fa-3x fa-times"></i>
            </a>
            <div class="container text-center">
              <div class="row">
                <div class="col-lg-8 mx-auto">
                  <h2 class="text-secondary text-uppercase mb-0">Project Name</h2>
                  <hr class="star-dark mb-5">
                  <img class="img-fluid mb-5" src="img/portfolio/cake.png" alt="">
                  <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
                  <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                    <i class="fa fa-close"></i>
                  Close Project</a>
                </div>
              </div>
            </div>
          </div>
        </div> -->

        <!-- Portfolio Modal 3 -->
        <!-- <div class="portfolio-modal mfp-hide" id="portfolio-modal-3">
          <div class="portfolio-modal-dialog bg-white">
            <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
              <i class="fa fa-3x fa-times"></i>
            </a>
            <div class="container text-center">
              <div class="row">
                <div class="col-lg-8 mx-auto">
                  <h2 class="text-secondary text-uppercase mb-0">Project Name</h2>
                  <hr class="star-dark mb-5">
                  <img class="img-fluid mb-5" src="img/portfolio/circus.png" alt="">
                  <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
                  <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                    <i class="fa fa-close"></i>
                  Close Project</a>
                </div>
              </div>
            </div>
          </div>
        </div> -->

        <!-- Portfolio Modal 4 -->
        <!-- <div class="portfolio-modal mfp-hide" id="portfolio-modal-4">
          <div class="portfolio-modal-dialog bg-white">
            <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
              <i class="fa fa-3x fa-times"></i>
            </a>
            <div class="container text-center">
              <div class="row">
                <div class="col-lg-8 mx-auto">
                  <h2 class="text-secondary text-uppercase mb-0">Project Name</h2>
                  <hr class="star-dark mb-5">
                  <img class="img-fluid mb-5" src="img/portfolio/game.png" alt="">
                  <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
                  <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                    <i class="fa fa-close"></i>
                  Close Project</a>
                </div>
              </div>
            </div>
          </div>
        </div> -->

        <!-- Portfolio Modal 5 -->
       <!--  <div class="portfolio-modal mfp-hide" id="portfolio-modal-5">
          <div class="portfolio-modal-dialog bg-white">
            <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
              <i class="fa fa-3x fa-times"></i>
            </a>
            <div class="container text-center">
              <div class="row">
                <div class="col-lg-8 mx-auto">
                  <h2 class="text-secondary text-uppercase mb-0">Project Name</h2>
                  <hr class="star-dark mb-5">
                  <img class="img-fluid mb-5" src="img/portfolio/safe.png" alt="">
                  <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
                  <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                    <i class="fa fa-close"></i>
                  Close Project</a>
                </div>
              </div>
            </div>
          </div>
        </div> -->

        <!-- Portfolio Modal 6 -->
       <!--  <div class="portfolio-modal mfp-hide" id="portfolio-modal-6">
          <div class="portfolio-modal-dialog bg-white">
            <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
              <i class="fa fa-3x fa-times"></i>
            </a>
            <div class="container text-center">
              <div class="row">
                <div class="col-lg-8 mx-auto">
                  <h2 class="text-secondary text-uppercase mb-0">Project Name</h2>
                  <hr class="star-dark mb-5">
                  <img class="img-fluid mb-5" src="img/portfolio/submarine.png" alt="">
                  <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
                  <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                    <i class="fa fa-close"></i>
                  Close Project</a>
                </div>
              </div>
            </div>
          </div>
        </div> -->

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Plugin JavaScript -->
        <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
        <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

        <!-- Contact Form JavaScript -->
        <script src="js/jqBootstrapValidation.js"></script>
        <script src="js/contact_me.js"></script>

        <!-- Custom scripts for this template -->
        <script src="js/freelancer.min.js"></script>

      </body>

      </html>
